var config = {
  GOOGLEMAPAPI : 'https://maps.googleapis.com/maps/api/js?key=AIzaSyBf6Me2Cp1c-Ib9d9AOZUH68t9oOw9293U&callback=initMap'
}
