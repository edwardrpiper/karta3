var mykey = config.GOOGLEMAPAPI;
document.write("<script src='"+ mykey + "'async defer><\/scr" + "ipt>");
